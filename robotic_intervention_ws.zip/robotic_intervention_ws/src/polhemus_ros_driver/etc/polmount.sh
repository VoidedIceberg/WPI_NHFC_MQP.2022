sudo mount --bind /dev/bus /proc/bus && sudo ln -s /sys/kernel/debug/usb/devices /proc/bus/usb/devices
